"""
powershell_cmd — run a PowerShell (Windows) or shell (Unix) command safely.

Security model:
  * Explicit allowlist of safe command prefixes by default
  * Dangerous patterns blocked (format, del system paths, shutdown, etc.)
  * Timeout, no shell injection via argument vector where possible
  * Confirmation required for elevated / destructive commands via core.confirm
"""
from __future__ import annotations

from typing import Optional

import platform
import re
import shlex
import subprocess
from pathlib import Path

from core.outcome import done, failed, unverified, ask

_OS = platform.system()

# Commands that are always refused (case-insensitive substring match on the
# full command string after normalisation).
_BLOCKED = (
    r"format\s+[a-z]:",
    r"remove-item\s+.*(-recurse|-r).*(\\windows|\\system32|/etc|/usr)",
    r"rm\s+-rf\s+/(etc|usr|var|home|boot|sys|dev)?\s*$",
    r"shutdown",
    r"restart-computer",
    r"stop-computer",
    r"disable-computerrestore",
    r"clear-disk",
    r"reset-computerachinepassword",
    r"remove-computer",
    r"cipher\s+/w",
    r"dd\s+if=",
    r"mkfs\.",
    r":\(\)\s*\{\s*:\|:&\s*\};:",  # fork bomb
)

# Prefer these prefixes when the model invents something vague.
_SAFE_PREFIXES_WIN = (
    "get-", "select-", "where-", "foreach-", "measure-", "write-output",
    "write-host", "echo", "dir", "ls", "cat", "type", "pwd", "cd",
    "test-path", "resolve-path", "get-childitem", "get-content",
    "get-process", "get-service", "get-date", "get-location",
    "convertto-json", "convertfrom-json", "out-string",
    "ipconfig", "systeminfo", "whoami", "hostname", "netstat",
    "ping", "nslookup", "tracert", "arp", "route", "net ",
)

_SAFE_PREFIXES_UNIX = (
    "ls", "pwd", "echo", "cat", "head", "tail", "wc", "df", "du", "free",
    "ps", "top", "uptime", "uname", "whoami", "id", "date", "cal",
    "ip", "ifconfig", "ping", "ss", "netstat", "dig", "host",
    "git", "python", "python3", "node", "npm", "pip", "which", "type",
    "find", "grep", "rg", "sed", "awk", "sort", "uniq", "cut", "tr",
)


def _is_blocked(cmd: str) -> Optional[str]:
    low = cmd.lower().strip()
    for pat in _BLOCKED:
        if re.search(pat, low, re.I):
            return f"blocked dangerous pattern: {pat}"
    # Refuse absolute wipe of home root
    if re.search(r"(rm\s+-rf\s+~/?\s*$|remove-item\s+-recurse\s+\$?home)", low):
        return "refusing to recursively delete home directory"
    return None


def _looks_safe(cmd: str) -> bool:
    low = cmd.strip().lower()
    prefixes = _SAFE_PREFIXES_WIN if _OS == "Windows" else _SAFE_PREFIXES_UNIX
    return any(low.startswith(p) for p in prefixes)


def _run_windows(cmd: str, timeout: float) -> tuple[int, str, str]:
    # Use -Command with encoded-free UTF-8 via stdin to avoid code-page issues
    full = [
        "powershell",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy", "Bypass",
        "-Command",
        cmd,
    ]
    try:
        r = subprocess.run(
            full,
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=0x08000000,
            encoding="utf-8",
            errors="replace",
        )
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout}s"
    except Exception as e:
        return 1, "", str(e)


def _run_unix(cmd: str, timeout: float) -> tuple[int, str, str]:
    # Prefer argument vector when the command is simple; else bash -c
    try:
        parts = shlex.split(cmd, posix=True)
    except ValueError:
        parts = []
    if parts and not any(c in cmd for c in ("|", ";", "&&", "||", ">", "<", "`", "$(")):
        try:
            r = subprocess.run(
                parts, capture_output=True, text=True, timeout=timeout,
                encoding="utf-8", errors="replace",
            )
            return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
        except FileNotFoundError:
            return 127, "", f"command not found: {parts[0]}"
        except subprocess.TimeoutExpired:
            return 124, "", f"timeout after {timeout}s"
        except Exception as e:
            return 1, "", str(e)
    try:
        r = subprocess.run(
            ["/bin/bash", "-c", cmd],
            capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace",
        )
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout}s"
    except Exception as e:
        return 1, "", str(e)


def powershell_cmd(parameters=None, **_ctx) -> str:
    params = parameters or {}
    cmd = (params.get("command") or params.get("cmd") or "").strip()
    timeout = float(params.get("timeout") or 30)
    timeout = max(3.0, min(timeout, 120.0))
    force = bool(params.get("force", False))

    if not cmd:
        return failed("powershell_cmd", "command is required")

    blocked = _is_blocked(cmd)
    if blocked:
        return failed("powershell_cmd", blocked, command=cmd[:200])

    # Non-allowlisted commands need explicit force=true (model must explain why)
    if not _looks_safe(cmd) and not force:
        return ask(
            "powershell_cmd",
            "This command is not on the safe allowlist. "
            "Confirm with the user and call again with force=true if they agree.",
            command=cmd[:300],
        )

    if _OS == "Windows":
        code, out, err = _run_windows(cmd, timeout)
        shell = "powershell"
    else:
        code, out, err = _run_unix(cmd, timeout)
        shell = "bash"

    # Truncate huge outputs so the model stays usable
    max_out = 4000
    if len(out) > max_out:
        out = out[:max_out] + f"\n… [truncated, {len(out)} chars total]"
    if len(err) > 1500:
        err = err[:1500] + " …"

    if code == 0:
        return done(
            "powershell_cmd",
            shell=shell,
            exit_code=code,
            output=out or "(no output)",
            command=cmd[:200],
        )
    if code == 124:
        return failed("powershell_cmd", f"timeout after {timeout}s", command=cmd[:200])
    return failed(
        "powershell_cmd",
        err or f"exit code {code}",
        exit_code=code,
        output=out or "",
        command=cmd[:200],
    )


TOOL = {
    "name": "powershell_cmd",
    "description": (
        "Runs a shell command on this computer and returns stdout/stderr. "
        "On Windows this is PowerShell; on macOS/Linux it is bash. "
        "Use for system queries (processes, network, files, git status, etc.). "
        "Safe read-only commands run immediately. Destructive or uncommon "
        "commands require force=true after the user confirms. "
        "Never use this to format disks, wipe system folders, or shut down "
        "the machine — those are blocked. Prefer specialised tools "
        "(file_controller, open_app, window_manager) when they fit better."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "command": {
                "type": "STRING",
                "description": "The exact command to run.",
            },
            "cmd": {
                "type": "STRING",
                "description": "Alias for command.",
            },
            "timeout": {
                "type": "NUMBER",
                "description": "Seconds before abort (3–120, default 30).",
            },
            "force": {
                "type": "BOOLEAN",
                "description": "Required for commands outside the safe allowlist.",
            },
        },
        "required": ["command"],
    },
    "handler": powershell_cmd,
    "tier": "core",
}
