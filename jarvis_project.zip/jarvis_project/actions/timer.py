"""
Action: timer — countdown timers with a spoken/log notification when done.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime, timedelta
from typing import Optional

# In-process timer registry (name -> cancel Event)
_timers: dict[str, threading.Event] = {}
_lock = threading.Lock()


def _log(msg: str, player=None) -> None:
    print(f"[Timer] {msg}")
    if player:
        try:
            player.write_log(f"JARVIS: {msg}")
        except Exception:
            pass


def _parse_seconds(parameters: dict) -> Optional[int]:
    """Accept seconds, minutes, or a combined phrase-friendly set of fields."""
    if parameters.get("seconds") is not None:
        try:
            s = int(float(parameters["seconds"]))
            if s > 0:
                return s
        except (TypeError, ValueError):
            pass
    if parameters.get("minutes") is not None:
        try:
            m = float(parameters["minutes"])
            if m > 0:
                return max(1, int(m * 60))
        except (TypeError, ValueError):
            pass
    # "duration" as "10m", "30s", "1h", "1h30m"
    dur = (parameters.get("duration") or "").strip().lower().replace(" ", "")
    if not dur:
        return None
    total = 0
    import re
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)(h|m|s|min|hora|horas|minuto|minutos|segundo|segundos)?", dur):
        n = float(num)
        u = (unit or "m").lower()
        if u in ("h", "hora", "horas"):
            total += int(n * 3600)
        elif u in ("s", "segundo", "segundos"):
            total += int(n)
        else:
            total += int(n * 60)
    return total if total > 0 else None


def _notify_done(label: str, player=None) -> None:
    msg = f"Timer finished: {label}." if label else "Your timer is up, sir."
    _log(msg, player)
    # Best-effort system beep / notification
    try:
        import platform
        if platform.system() == "Windows":
            import winsound
            for f in (900, 1100, 1300):
                winsound.Beep(f, 160)
        else:
            print("\a")
    except Exception:
        pass
    # Try to speak via player if the live session exposes a hook
    if player:
        try:
            say = getattr(player, "plugin_say", None) or getattr(player, "say", None)
            if callable(say):
                say(msg)
        except Exception:
            pass


def timer_action(
    parameters: dict,
    player=None,
    session_memory=None,
) -> str:
    action = (parameters.get("action") or "start").strip().lower()
    label = (parameters.get("label") or parameters.get("name") or "timer").strip()[:80]

    if action in ("list", "status"):
        with _lock:
            names = list(_timers.keys())
        if not names:
            return "No active timers, sir."
        return "Active timers: " + ", ".join(names) + "."

    if action in ("cancel", "stop", "clear"):
        target = label if label != "timer" else (parameters.get("label") or "")
        with _lock:
            if target and target in _timers:
                _timers[target].set()
                del _timers[target]
                msg = f"Cancelled timer '{target}'."
            elif not target and _timers:
                for ev in _timers.values():
                    ev.set()
                n = len(_timers)
                _timers.clear()
                msg = f"Cancelled {n} timer(s)."
            else:
                msg = "No matching timer to cancel."
        _log(msg, player)
        return msg

    # start
    seconds = _parse_seconds(parameters)
    if not seconds:
        return (
            "Sir, tell me the duration — for example minutes=10, "
            "seconds=90, or duration='25m'."
        )
    if seconds > 24 * 3600:
        return "Sir, maximum timer is 24 hours."

    # unique name if collision
    name = label
    with _lock:
        base = name
        i = 2
        while name in _timers:
            name = f"{base}-{i}"
            i += 1
        cancel = threading.Event()
        _timers[name] = cancel

    ends = datetime.now() + timedelta(seconds=seconds)
    ends_str = ends.strftime("%H:%M")

    def _worker():
        remaining = seconds
        # sleep in chunks so cancel is responsive
        while remaining > 0:
            step = min(1.0, remaining)
            if cancel.wait(step):
                return  # cancelled
            remaining -= step
        with _lock:
            _timers.pop(name, None)
        _notify_done(name, player)

    t = threading.Thread(target=_worker, daemon=True, name=f"jarvis-timer-{name}")
    t.start()

    if seconds < 60:
        human = f"{seconds} seconds"
    elif seconds % 60 == 0:
        human = f"{seconds // 60} minutes"
    else:
        human = f"{seconds // 60} min {seconds % 60} s"

    msg = f"Timer '{name}' set for {human}. It will finish around {ends_str}."
    _log(msg, player)
    return msg


TOOL = {
    "name": "timer",
    "description": (
        "Starts, lists or cancels countdown timers. "
        "Use for 'remind me in 10 minutes', 'pomodoro 25 minutes', "
        "'cancel the timer', 'what timers are running'. "
        "When the timer ends the user is notified (beep + log)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "start (default) | list | cancel",
            },
            "minutes": {
                "type": "NUMBER",
                "description": "Duration in minutes (e.g. 10 or 25)",
            },
            "seconds": {
                "type": "NUMBER",
                "description": "Duration in seconds (alternative to minutes)",
            },
            "duration": {
                "type": "STRING",
                "description": "Human duration like '10m', '1h', '90s', '1h30m'",
            },
            "label": {
                "type": "STRING",
                "description": "Optional name for the timer (e.g. 'pomodoro', 'tea')",
            },
        },
        "required": [],
    },
    "handler": timer_action,
    "behavior": "NON_BLOCKING",
    "scheduling": "SILENT",
}
