"""
Action: clipboard — read, write or clear the system clipboard.
"""
from __future__ import annotations

from typing import Optional

try:
    import pyperclip
    _HAS = True
except ImportError:
    _HAS = False


def _log(msg: str, player=None) -> None:
    print(f"[Clipboard] {msg}")
    if player:
        try:
            player.write_log(f"JARVIS: {msg}")
        except Exception:
            pass


def clipboard_action(
    parameters: dict,
    player=None,
    session_memory=None,
) -> str:
    if not _HAS:
        return "Sir, the clipboard tool needs the pyperclip package."

    action = (parameters.get("action") or "get").strip().lower()
    text = parameters.get("text")

    try:
        if action in ("get", "read", "show"):
            content = pyperclip.paste()
            if not content or not str(content).strip():
                msg = "The clipboard is empty, sir."
            else:
                content = str(content)
                # Keep spoken reply short; long content is still returned fully
                preview = content.strip().replace("\n", " ")
                if len(preview) > 280:
                    preview = preview[:277] + "..."
                msg = f"Clipboard contains: {preview}"
            _log(msg, player)
            return msg

        if action in ("set", "copy", "write"):
            if text is None or str(text).strip() == "":
                return "Sir, there is no text to copy to the clipboard."
            pyperclip.copy(str(text))
            preview = str(text).strip().replace("\n", " ")
            if len(preview) > 120:
                preview = preview[:117] + "..."
            msg = f"Copied to clipboard: {preview}"
            _log(msg, player)
            return msg

        if action in ("clear", "empty"):
            pyperclip.copy("")
            msg = "Clipboard cleared, sir."
            _log(msg, player)
            return msg

        return (
            "Sir, use action get, set or clear. "
            "For set, also provide the text to copy."
        )
    except Exception as e:
        return f"Sir, clipboard failed: {e}"


TOOL = {
    "name": "clipboard",
    "description": (
        "Reads, writes or clears the system clipboard. "
        "Use when the user asks what is on the clipboard, to copy text, "
        "or to clear it. Actions: get (read), set (copy text), clear."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "get | set | clear. Default: get",
            },
            "text": {
                "type": "STRING",
                "description": "Text to copy when action is set",
            },
        },
        "required": [],
    },
    "handler": clipboard_action,
}
