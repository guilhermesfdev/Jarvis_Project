"""
Plugin: programador — escreve e melhora código Python, inclusive a si mesmo.

Fluxo de auto-melhoria / novas skills:
1. Gera ou melhora um .py e salva em plugins/pending/<nome>.py
2. Você revisa o arquivo em plugins/pending/
3. Quando pedir pra aplicar / instalar / aprovar, aparece a tela de
   confirmação na UI (ConfirmBanner). Se confirmar, o arquivo é
   movido de pending/ para plugins/ (e o JARVIS precisa reiniciar
   pra carregar).

Também serve pra escrever funções soltas, scripts e pequenos utilitários.
"""

from __future__ import annotations

import re
import shutil
import time
from pathlib import Path

from core import confirm, gemini

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def _plugins_dir() -> Path:
    return Path(__file__).resolve().parent


def _pending_dir() -> Path:
    d = _plugins_dir() / "pending"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------------------------------------------------------------------------
# PLUGIN meta
# ---------------------------------------------------------------------------

PLUGIN = {
    "name": "programador",
    "description": (
        "Escreve, melhora e propõe código Python. "
        "Use quando o usuário pedir pra criar um plugin, melhorar um plugin "
        "existente (incluindo este), escrever uma função, um script, ou "
        "'se auto melhorar'. "
        "Propostas novas vão SEMPRE para plugins/pending/<nome>.py. "
        "Depois que o usuário revisar, use a ação 'aplicar' / 'instalar' / "
        "'aprovar' para pedir confirmação na interface e mover o arquivo "
        "de pending/ para plugins/. "
        "NÃO escreva direto em plugins/ — só em pending/."
    ),
    "tier": "extra",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "acao": {
                "type": "STRING",
                "description": (
                    "O que fazer: "
                    "'propor' (gerar/melhorar código e salvar em pending), "
                    "'listar' (mostrar o que tem em pending), "
                    "'ler' (mostrar o conteúdo de um pending), "
                    "'aplicar' (pedir confirmação na UI e mover pending → plugins), "
                    "'descartar' (apagar um arquivo de pending)."
                ),
            },
            "nome": {
                "type": "STRING",
                "description": (
                    "Nome do plugin/arquivo sem .py (ex: 'whatsapp_web', "
                    "'programador', 'meu_util'). Obrigatório em propor/ler/aplicar/descartar."
                ),
            },
            "pedido": {
                "type": "STRING",
                "description": (
                    "O que o usuário quer que o código faça ou melhore. "
                    "Use em 'propor'. Ex: 'adiciona retry no envio', "
                    "'cria um plugin que toca um alarme'."
                ),
            },
            "base": {
                "type": "STRING",
                "description": (
                    "Opcional. Código atual ou caminho relativo (ex: 'plugins/whatsapp_web.py') "
                    "pra usar como base da melhoria. Se vazio e nome=programador, "
                    "lê o próprio arquivo."
                ),
            },
        },
        "required": ["acao"],
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SAFE_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")


def _safe_stem(nome: str) -> str | None:
    nome = (nome or "").strip().removesuffix(".py")
    if not nome or not _SAFE_NAME.match(nome):
        return None
    if nome.startswith("_"):
        return None
    return nome


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _write_pending(stem: str, code: str) -> Path:
    path = _pending_dir() / f"{stem}.py"
    path.write_text(code, encoding="utf-8")
    return path


def _list_pending() -> list[str]:
    return sorted(p.stem for p in _pending_dir().glob("*.py") if p.is_file())


def _load_base_code(nome: str, base: str) -> str:
    """Resolve o código-base pra melhoria."""
    base = (base or "").strip()
    if base:
        # Se parece caminho
        if base.endswith(".py") or "/" in base or "\\" in base:
            p = Path(base)
            if not p.is_absolute():
                p = _plugins_dir().parent / base
            if p.is_file():
                return _read_text(p)
        # Senão trata como código cru
        if "def " in base or "PLUGIN" in base or "import " in base:
            return base

    # Auto: se for o próprio programador ou um plugin existente
    stem = _safe_stem(nome) or ""
    candidates = [
        _plugins_dir() / f"{stem}.py",
        _pending_dir() / f"{stem}.py",
    ]
    for c in candidates:
        if c.is_file():
            return _read_text(c)
    return ""


def _generate_code(pedido: str, nome: str, base_code: str) -> str:
    """Pede ao modelo um plugin Python completo e válido."""
    stem = _safe_stem(nome) or "novo_plugin"

    system = (
        "Você é um programador Python sênior do projeto JARVIS (Mark LVI). "
        "Escreva UM arquivo de plugin completo, pronto pra rodar. "
        "Regras obrigatórias:\n"
        "- O arquivo DEVE ter um dict PLUGIN com name, description, parameters.\n"
        "- DEVE ter def run(parameters: dict, player=None, session_memory=None) -> str\n"
        "- Nunca use genai.Client direto; use core.gemini se precisar de LLM.\n"
        "- Type hints, pathlib, f-strings, funções pequenas.\n"
        "- Nunca apague arquivos ou faça ações destrutivas sem confirmação.\n"
        "- Resposta: APENAS o código Python, sem markdown, sem explicação.\n"
        f"- O PLUGIN['name'] deve ser exatamente: {stem}\n"
    )

    if base_code:
        prompt = (
            f"{system}\n\n"
            f"## Código atual (melhore / adapte conforme o pedido)\n"
            f"```python\n{base_code[:12000]}\n```\n\n"
            f"## Pedido do usuário\n{pedido}\n\n"
            f"Gere o arquivo completo já atualizado."
        )
    else:
        prompt = (
            f"{system}\n\n"
            f"## Pedido do usuário\n{pedido}\n\n"
            f"Crie o plugin do zero. Nome: {stem}"
        )

    raw = gemini.text(prompt, tier=gemini.SMART, timeout_ms=90_000)
    # Limpa cercas de markdown se o modelo teimar
    code = raw.strip()
    if code.startswith("```"):
        code = re.sub(r"^```(?:python)?\s*", "", code)
        code = re.sub(r"\s*```$", "", code)
    return code.strip() + "\n"


def _apply_move(stem: str) -> str:
    src = _pending_dir() / f"{stem}.py"
    dst = _plugins_dir() / f"{stem}.py"
    if not src.is_file():
        return f"Não achei plugins/pending/{stem}.py"
    # Backup se já existir
    if dst.is_file():
        bak = _plugins_dir() / f"{stem}.bak.{int(time.time())}.py"
        shutil.copy2(dst, bak)
    shutil.move(str(src), str(dst))
    return (
        f"Plugin '{stem}' instalado em plugins/{stem}.py. "
        f"Reinicie o JARVIS para carregar."
    )


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------

def run(parameters: dict, player=None, session_memory=None) -> str:
    acao = (parameters.get("acao") or "").strip().lower()
    nome = (parameters.get("nome") or "").strip()
    pedido = (parameters.get("pedido") or "").strip()
    base = (parameters.get("base") or "").strip()

    if player:
        try:
            player.write_log(f"JARVIS: programador → {acao} {nome or ''}".strip())
        except Exception:
            pass

    # ---- listar ----
    if acao in ("listar", "list", "pending"):
        itens = _list_pending()
        if not itens:
            return "Nada em plugins/pending/ no momento."
        return "Pendentes de revisão:\n- " + "\n- ".join(itens)

    # ---- ler ----
    if acao in ("ler", "read", "mostrar"):
        stem = _safe_stem(nome)
        if not stem:
            return "Me diga o nome do arquivo em pending (ex: programador)."
        path = _pending_dir() / f"{stem}.py"
        if not path.is_file():
            return f"Não achei plugins/pending/{stem}.py"
        code = _read_text(path)
        # Resposta curta pro modelo; o usuário pode abrir o arquivo
        preview = code[:1500] + ("…" if len(code) > 1500 else "")
        return f"Conteúdo de pending/{stem}.py ({len(code)} chars):\n\n{preview}"

    # ---- descartar ----
    if acao in ("descartar", "delete", "apagar", "remover"):
        stem = _safe_stem(nome)
        if not stem:
            return "Me diga qual pending descartar."
        path = _pending_dir() / f"{stem}.py"
        if not path.is_file():
            return f"Não achei plugins/pending/{stem}.py"
        path.unlink()
        return f"Descartei pending/{stem}.py."

    # ---- aplicar (com confirmação na UI) ----
    if acao in ("aplicar", "instalar", "aprovar", "apply", "install"):
        stem = _safe_stem(nome)
        if not stem:
            return "Me diga o nome do pending pra instalar (ex: programador)."
        src = _pending_dir() / f"{stem}.py"
        if not src.is_file():
            return f"Não achei plugins/pending/{stem}.py pra instalar."

        if confirm.pending_title():
            return (
                "Já tem uma confirmação na tela. "
                "Confirma ou cancela ela antes de pedir outra."
            )

        def _do_install() -> str:
            return _apply_move(stem)

        return confirm.request(
            key=f"install-plugin-{stem}",
            title=f"Instalar plugin '{stem}'",
            detail=(
                f"Mover plugins/pending/{stem}.py → plugins/{stem}.py\n"
                f"Se já existir, o atual vira .bak. "
                f"Reinicie o JARVIS depois pra carregar."
            ),
            run=_do_install,
        )

    # ---- propor (gerar / melhorar) ----
    if acao in ("propor", "criar", "melhorar", "gerar", "escrever", "propose"):
        stem = _safe_stem(nome)
        if not stem:
            return (
                "Me diga o nome do plugin (ex: 'alarme', 'programador'). "
                "Vou salvar em plugins/pending/<nome>.py"
            )
        if not pedido:
            return "Me diga o que o código deve fazer ou melhorar."

        base_code = _load_base_code(stem, base)

        if player:
            try:
                player.write_log(f"JARVIS: Gerando código pra pending/{stem}.py …")
            except Exception:
                pass

        try:
            code = _generate_code(pedido, stem, base_code)
        except Exception as e:
            return f"Falha ao gerar código: {e}"

        if "PLUGIN" not in code or "def run" not in code:
            return (
                "O modelo devolveu algo que não parece um plugin válido "
                "(falta PLUGIN ou def run). Tenta de novo com mais detalhes."
            )

        path = _write_pending(stem, code)
        return (
            f"Proposta salva em plugins/pending/{stem}.py ({len(code)} chars). "
            f"Revise o arquivo. Quando estiver ok, diga "
            f"'aplica o {stem}' ou 'instala o plugin {stem}' "
            f"que eu peço confirmação na tela pra mover pra plugins/."
        )

    return (
        "Ações: propor | listar | ler | aplicar | descartar. "
        "Ex: acao=propor, nome=meu_plugin, pedido='faz X'."
    )
