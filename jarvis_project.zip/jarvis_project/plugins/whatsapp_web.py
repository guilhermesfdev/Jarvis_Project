"""
Plugin: WhatsApp Web — manda mensagem pelo navegador (web.whatsapp.com).

Fluxo:
1. Abre web.whatsapp.com no navegador padrão
2. Fica capturando a tela em loop (monitoramento ativo)
3. Tenta focar a busca por atalho; se não der certo, move o mouse,
   clica no campo de pesquisa e tenta de novo
4. Digita o nome, entra na conversa e envia a mensagem
5. Só para de capturar depois de dar Enter na mensagem

Trigger natural: "mande mensagem para fulano", "envia no WhatsApp pro X", etc.
"""

from __future__ import annotations

import sys
import threading
import time
import webbrowser

try:
    from core.lazyimport import LazyModule, installed
except ImportError:
    from config.lazyimport import LazyModule, installed

_PYAUTOGUI = installed("pyautogui")
_PYPERCLIP = installed("pyperclip")


def _configure_pyautogui(module) -> None:
    module.FAILSAFE = True
    module.PAUSE = 0.06


pyautogui = LazyModule("pyautogui", _configure_pyautogui)
pyperclip = LazyModule("pyperclip")


PLUGIN = {
    "name": "whatsapp_web",
    "description": (
        "Envia mensagem pelo WhatsApp Web (navegador). "
        "Use SEMPRE que o usuário disser 'mande mensagem para X', "
        "'envia pro fulano no WhatsApp', 'manda no Zap pra...', "
        "ou qualquer variação de enviar mensagem pelo WhatsApp Web. "
        "NÃO use send_message quando o usuário pedir explicitamente "
        "a versão web / navegador. Abre web.whatsapp.com, monitora a tela "
        "continuamente até enviar a mensagem, pesquisa o contato e digita. "
        "Se o atalho de busca falhar, move o mouse pro campo de pesquisa, "
        "clica e tenta de novo."
    ),
    "tier": "core",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "receiver": {
                "type": "STRING",
                "description": "Nome do contato (ex: mãe, Talita, João)",
            },
            "message_text": {
                "type": "STRING",
                "description": "Texto da mensagem, no idioma do usuário",
            },
        },
        "required": ["receiver", "message_text"],
    },
}


def _paste(text: str) -> None:
    if not _PYAUTOGUI:
        raise RuntimeError("PyAutoGUI não instalado. Rode: pip install pyautogui")
    if _PYPERCLIP:
        pyperclip.copy(text)
        time.sleep(0.12)
        if sys.platform == "darwin":
            pyautogui.hotkey("command", "v")
        else:
            pyautogui.hotkey("ctrl", "v")
    else:
        pyautogui.write(text, interval=0.03)
    time.sleep(0.15)


def _clear_field() -> None:
    if sys.platform == "darwin":
        pyautogui.hotkey("command", "a")
    else:
        pyautogui.hotkey("ctrl", "a")
    time.sleep(0.1)
    pyautogui.press("backspace")
    time.sleep(0.12)


def _capture_once() -> bool:
    """Uma captura de tela. Retorna True se ok."""
    try:
        from actions.screen_processor import _capture_screen
        img, _mime = _capture_screen()
        return bool(img and len(img) > 1000)
    except Exception:
        return False


def _monitor_loop(stop_event: threading.Event, player=None) -> None:
    """Captura a tela a cada ~0.8s até stop_event ser setado."""
    count = 0
    while not stop_event.is_set():
        ok = _capture_once()
        count += 1
        if player and count % 3 == 1:
            try:
                status = "ok" if ok else "falhou"
                player.write_log(f"JARVIS: Monitor tela #{count} — {status}")
            except Exception:
                pass
        stop_event.wait(0.8)


def _click_search_bar() -> None:
    """
    Move o mouse pro canto superior esquerdo (onde fica a busca do WhatsApp Web)
    e clica. Usa posição relativa à resolução pra funcionar em telas diferentes.
    """
    w, h = pyautogui.size()
    # Campo de busca fica mais ou menos em 12–18% da largura e 8–12% da altura
    # Tentamos dois pontos comuns (com e sem barra lateral expandida)
    points = [
        (int(w * 0.14), int(h * 0.10)),
        (int(w * 0.12), int(h * 0.09)),
        (int(w * 0.18), int(h * 0.11)),
    ]
    for x, y in points:
        pyautogui.moveTo(x, y, duration=0.25)
        time.sleep(0.15)
        pyautogui.click()
        time.sleep(0.35)


def _focus_search(player=None) -> None:
    """
    Tenta focar a busca por atalho. Se parecer que não funcionou,
    move o mouse, clica no campo e tenta de novo.
    """
    # Tentativa 1: atalho oficial do WhatsApp Web
    if sys.platform == "darwin":
        pyautogui.hotkey("command", "alt", "/")
    else:
        pyautogui.hotkey("ctrl", "alt", "/")
    time.sleep(0.7)

    # Digita um caractere de teste e apaga pra ver se o foco está certo
    # (se o foco não estiver no campo, o caractere não aparece / não apaga limpo)
    # Na prática: se o atalho falhou, o campo ainda não está ativo → usamos o mouse
    try:
        # Fallback sempre disponível: clica no campo de pesquisa
        # (mais confiável que adivinhar se o atalho pegou)
        if player:
            try:
                player.write_log("JARVIS: Focando busca (atalho + mouse fallback)")
            except Exception:
                pass

        _click_search_bar()
        time.sleep(0.4)

        # Segunda tentativa de atalho depois do clique (garante foco)
        if sys.platform == "darwin":
            pyautogui.hotkey("command", "alt", "/")
        else:
            pyautogui.hotkey("ctrl", "alt", "/")
        time.sleep(0.5)

    except Exception:
        # Se até o mouse falhar, pelo menos o atalho já foi tentado
        pass


def _search_and_open_contact(receiver: str, player=None) -> None:
    """Foca a busca, digita o nome e entra na conversa. Com retry por mouse."""
    _focus_search(player)

    _clear_field()
    _paste(receiver)
    time.sleep(1.4)

    # Entra no primeiro resultado
    pyautogui.press("enter")
    time.sleep(1.1)

    # Se ainda parecer que não entrou (pouco tempo / falha comum),
    # tenta de novo com mouse + pesquisa
    # (segunda chance: clica de novo na busca e repete)
    try:
        if player:
            try:
                player.write_log("JARVIS: Segunda tentativa de busca (mouse + nome)")
            except Exception:
                pass

        _click_search_bar()
        time.sleep(0.4)
        _clear_field()
        _paste(receiver)
        time.sleep(1.3)
        pyautogui.press("enter")
        time.sleep(1.0)
    except Exception:
        pass


def run(parameters: dict, player=None, session_memory=None) -> str:
    receiver = (parameters.get("receiver") or "").strip()
    message = (parameters.get("message_text") or "").strip()

    if not receiver:
        return "Preciso do nome do contato, senhor."
    if not message:
        return "Preciso do texto da mensagem."

    if not _PYAUTOGUI:
        return (
            "PyAutoGUI não está instalado. "
            "Rode: pip install pyautogui pyperclip"
        )

    if player:
        try:
            player.write_log(f"JARVIS: Abrindo WhatsApp Web → {receiver}")
        except Exception:
            pass

    # 1. Abre a aba
    try:
        webbrowser.open("https://web.whatsapp.com")
    except Exception as e:
        return f"Não consegui abrir o navegador: {e}"

    # 2. Inicia monitoramento contínuo da tela
    stop_event = threading.Event()
    monitor = threading.Thread(
        target=_monitor_loop,
        args=(stop_event, player),
        daemon=True,
        name="wa-web-monitor",
    )
    monitor.start()

    if player:
        try:
            player.write_log("JARVIS: Monitoramento de tela ATIVO")
        except Exception:
            pass

    try:
        # Espera a página carregar enquanto o monitor roda
        time.sleep(6.0)

        # 3. Busca o contato (atalho → se falhar, mouse + clique + tenta de novo)
        _search_and_open_contact(receiver, player)

        # 4. Digita e envia a mensagem
        _paste(message)
        time.sleep(0.3)
        pyautogui.press("enter")
        time.sleep(0.4)

    except Exception as e:
        stop_event.set()
        return (
            f"Abri o WhatsApp Web e monitei a tela, mas a digitação falhou: {e}. "
            "Confere se a aba está em foco e se você está logado."
        )
    finally:
        stop_event.set()
        monitor.join(timeout=2.0)

    if player:
        try:
            player.write_log("JARVIS: Monitoramento de tela ENCERRADO (mensagem enviada)")
        except Exception:
            pass

    return (
        f"Abri o WhatsApp Web, monitei a tela o tempo todo e enviei a mensagem pra {receiver}. "
        "Confere aí se chegou — não tenho como confirmar o envio pelo navegador."
    )
